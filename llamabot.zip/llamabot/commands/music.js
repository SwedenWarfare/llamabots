const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
  var rand = Math.floor((Math.random() * 15) + 1);
    message.delete().catch(O_o=>{});
      if(rand == 0){
        message.channel.send(`<@${message.author.id}> https://www.youtube.com/watch?v=-u4LqzKk-1g`);

      }
      if(rand == 1){
        message.channel.send(`<@${message.author.id}> https://www.youtube.com/watch?v=bc0sJvtKrRM`);

      }
      if(rand == 2){
        message.channel.send(`<@${message.author.id}> https://www.youtube.com/watch?v=EhGEGIBGLu8`);

      }
      if(rand == 3){
        message.channel.send(`<@${message.author.id}> https://www.youtube.com/watch?v=K5jvUXij7nU`);

      }
      if(rand == 4){
        message.channel.send(`<@${message.author.id}> https://www.youtube.com/watch?v=W3q8Od5qJio`);

      }
      if(rand == 5){
        message.channel.send(`<@${message.author.id}> https://www.youtube.com/watch?v=f55CqLc6IR0`);

      }
      if(rand == 6){
        message.channel.send(`<@${message.author.id}> https://www.youtube.com/watch?v=2G5rfPISIwo`);

      }
      if(rand == 7){
        message.channel.send(`<@${message.author.id}> https://www.youtube.com/watch?v=8aQRq9hhekA`);

      }
      if(rand == 8){
        message.channel.send(`<@${message.author.id}> https://www.youtube.com/watch?v=ZDZtbBZuqb0`);

      }
      if(rand == 9){
        message.channel.send(`<@${message.author.id}> https://www.youtube.com/watch?v=Rbm6GXllBiw`);

      }
      if(rand == 10){
        message.channel.send(`<@${message.author.id}> https://www.youtube.com/watch?v=xnKhsTXoKCI`);

      }
      if(rand == 11){
        message.channel.send(`<@${message.author.id}> https://www.youtube.com/watch?v=SRwrg0db_zY`);

      }
      if(rand == 12){
        message.channel.send(`<@${message.author.id}> https://www.youtube.com/watch?v=edBYB1VCV0k`);

      }
      if(rand == 13){
        message.channel.send(`<@${message.author.id}> https://www.youtube.com/watch?v=K6_zsJ8KPP0`);

      }
      if(rand == 14){
        message.channel.send(`<@${message.author.id}> https://www.youtube.com/watch?v=wSdFFougjr0`);

      }
      if(rand == 15){
        message.channel.send(`<@${message.author.id}> https://www.youtube.com/watch?v=L397TWLwrUU`);

      }

}

module.exports.help = {
  name:"music"
}
