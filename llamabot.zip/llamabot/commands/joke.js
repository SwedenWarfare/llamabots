const Discord = require("discord.js");


module.exports.run = async (bot, message, args) => {
  var rand = Math.floor((Math.random() * 11) + 1);
    message.delete().catch(O_o=>{});
      if(rand == 0){
        message.channel.send(`<@${message.author.id}> When I see lovers' names carved in a tree, I don't think its cute. I just think it's crazy how many people bring knives on a date.`);

      }
      if(rand == 1){
        message.channel.send(`<@${message.author.id}> I went to the zoo the other day, there was only one dog in it, it was a shitzu.`);

      }
      if(rand == 2){
        message.channel.send(`<@${message.author.id}>  man goes to the doctor with a carrot stuck up his nose and a banana sticking out of his ear and says “Doctor doctor! What’s wrong with me?” The doctor says “You’re not eating properly.”`);

      }
      if(rand == 3){
        message.channel.send(`<@${message.author.id}> You see my next-door neighbour worships exhaust pipes, he's a catholic converter.`);

      }
      if(rand == 4){
        message.channel.send(`<@${message.author.id}> A seal walks into a club...`);

      }
      if(rand == 5){
        message.channel.send(`<@${message.author.id}> I went to buy some camouflage trousers the other day but I couldn't find any.`);

      }
      if(rand == 6){
        message.channel.send(`<@${message.author.id}> Two cows are standing in a field. One cow says “Hey did you hear about that outbreak of mad cow disease? It makes cows go completely insane!”. The other cow replies “Good thing I’m a helicopter.”`);

      }
      if(rand == 7){
        message.channel.send(`<@${message.author.id}> A rope walks into a bar and orders a drink. The bartender says, “We don’t serve ropes in here.” The rope goes to the bathroom, ties itself up, messes up his hair and walks back to the bar and orders his drink. The bartender says, “Didn’t I just tell you? We don’t serve ropes in here.” The rope says, “I’m a frayed knot.”`);

      }
      if(rand == 8){
        message.channel.send(`<@${message.author.id}> What does a pirate do on the weekend? YARRRRRRRRdwork.`);

      }
      if(rand == 9){
        message.channel.send(`<@${message.author.id}> If you ever get cold, just stand in a corner for a bit. They're usually around 90 degrees`);

      }
      if(rand == 10){
        message.channel.send(`<@${message.author.id}> Why did the dinosaur cross the road? Because the chickens wasn't invented yet. `);

      }
      if(rand == 11){
        message.channel.send(`<@${message.author.id}> I used to be indecisive. Now I'm not sure.`);

      }
      if(rand == 12){
        message.channel.send(`<@${message.author.id}> Light travels faster than sound. This is why some people appear bright until you hear them speak.`);

      }
      if(rand == 13){
        message.channel.send(`<@${message.author.id}> Velcro—what a rip-off!`);

      }
      if(rand == 14){
        message.channel.send(`<@${message.author.id}> If there was someone selling drugs in this place, weed know.`);

      }
      if(rand == 15){
        message.channel.send(`<@${message.author.id}> The experienced carpenter really nailed it, but the new guy screwed everything up.`);

      }
      if(rand == 16){
        message.channel.send(`<@${message.author.id}> He drove his expensive car into a tree and found out how the Mercedes bends.`);

      }
      if(rand == 17){
        message.channel.send(`<@${message.author.id}> I don't trust these stairs because they're always up to something.`);

      }
      if(rand == 18){
        message.channel.send(`<@${message.author.id}> Show me a piano falling down a mineshaft and I'll show you A-flat minor.`);

      }
      if(rand == 19){
        message.channel.send(`<@${message.author.id}> Something about subtraction just doesn't add up.`);

      }
      if(rand == 20){
        message.channel.send(`<@${message.author.id}> Why don't programmers like nature? It has too many bugs.`);

      }
        }

module.exports.help = {
  name:"dadjoke"

}
