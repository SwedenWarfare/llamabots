const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
  var rand = Math.floor((Math.random() * 15) + 1);
    message.delete().catch(O_o=>{});
      if(rand == 0){
        message.channel.send(`<@${message.author.id}> https://www.reddit.com/r/gifs/comments/7v3k9w/the_matrix_dog_revolutions/`);

      }
      if(rand == 1){
        message.channel.send(`<@${message.author.id}> http://www.funnyjunk.com/funny_gifs/3174375/The+greatest+gif+i+have+ever+seen/`);

      }
      if(rand == 2){
        message.channel.send(`<@${message.author.id}> http://www.funnyjunk.com/funny_gifs/4035171/Bike+riding+level+over+9000/`);

      }
      if(rand == 3){
        message.channel.send(`<@${message.author.id}> https://www.reddit.com/r/gifs/comments/7v1xfx/dont_mind_me_im_just_a_bird/`);

      }
      if(rand == 4){
        message.channel.send(`<@${message.author.id}> http://www.funnyjunk.com/funny_gifs/2978187/Every/`);

      }
      if(rand == 5){
        message.channel.send(`<@${message.author.id}> https://gfycat.com/creepyjubilantgreathornedowl`);

      }
      if(rand == 6){
        message.channel.send(`<@${message.author.id}> https://i.imgur.com/bi1b3AD.gifv`);

      }
      if(rand == 7){
        message.channel.send(`<@${message.author.id}> https://zippy.gfycat.com/LivelyGreedyBat.webm`);

      }
      if(rand == 8){
        message.channel.send(`<@${message.author.id}> https://giant.gfycat.com/WealthyPalatableBlacklemur.webm`);

      }
      if(rand == 9){
        message.channel.send(`<@${message.author.id}> https://www.reddit.com/r/funnygifs/comments/74bq2f/bottle_flip_dab_smack/`);

      }
      if(rand == 10){
        message.channel.send(`<@${message.author.id}> https://media.giphy.com/media/xT9IgCVp69rqfJmges/giphy.gif`);

      }
      if(rand == 11){
        message.channel.send(`<@${message.author.id}> https://media.giphy.com/media/NUdzCkBlgL5w4/giphy.gif`);

      }
      if(rand == 12){
        message.channel.send(`<@${message.author.id}> https://i.imgur.com/aCFBiik.gifv`);

      }
      if(rand == 13){
        message.channel.send(`<@${message.author.id}> https://i.imgur.com/VKF2feC.gifv`);

      }
      if(rand == 14){
        message.channel.send(`<@${message.author.id}> https://i.imgur.com/7jXWYIh.gifv`);

      }
      if(rand == 15){
        message.channel.send(`<@${message.author.id}> https://gfycat.com/SafeThornyHylaeosaurus`);

      }
        }

module.exports.help = {
  name:"gif"
}
